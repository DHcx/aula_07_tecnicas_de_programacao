# TP2 - Aula 07 - Persistência de Dados e Padrão DAO

## FATEC - Desenvolvimento de Software Multiplataforma

Atividade prática da Aula 7 sobre persistência de dados e o padrão DAO.

## Objetivo

A atividade tem como objetivo separar a lógica de negócio do acesso aos dados utilizando o padrão DAO.

O projeto demonstra que a classe de negócio pode depender de uma abstração (`AlunoDAO`) e receber diferentes implementações sem precisar alterar suas regras.

## Etapa 1 - Diagnóstico

No problema original, a classe responsável pela regra de matrícula também executava comandos SQL.

Isso mistura duas responsabilidades:

1. Regra de negócio.
2. Acesso e persistência dos dados.

Essa mistura viola o princípio da Responsabilidade Única (SRP), pois uma mesma classe possui motivos diferentes para ser alterada.

Também existe um problema relacionado ao Princípio da Inversão de Dependência (DIP), pois a regra de negócio fica diretamente dependente de uma implementação de persistência.

Além disso, quando o mesmo bloco de busca de dados aparece em vários lugares, ocorre duplicação de código.

## Etapa 2 - Interface AlunoDAO

Foi criada a interface `AlunoDAO` com operações na linguagem do domínio:

- `inserir`
- `buscar`
- `listar`
- `atualizar`
- `remover`

A interface não utiliza termos de SQL como `INSERT`, tabela ou coluna.

```java
public interface AlunoDAO {

    void inserir(Aluno aluno);

    Aluno buscar(int id);

    List<Aluno> listar();

    void atualizar(Aluno aluno);

    void remover(int id);
}
```

## Etapa 3 - AlunoDAOMemoria

A classe `AlunoDAOMemoria` implementa `AlunoDAO` e utiliza um `Map<Integer, Aluno>` interno para armazenar os alunos.

Isso permite executar testes sem depender de um banco de dados.

## Etapa 4 - Refatoração da regra de negócio

A classe `MatriculaService` recebe um `AlunoDAO` pelo construtor:

```java
public MatriculaService(AlunoDAO alunoDAO) {
    this.alunoDAO = alunoDAO;
}
```

Dessa forma, a classe de negócio não conhece detalhes de persistência.

Ela depende apenas da interface `AlunoDAO`.

## Etapa 5 - Troca da implementação

Foi criada uma segunda implementação:

`AlunoDAOAlternativo`

Ela utiliza uma `List<Aluno>` em vez de um `Map`.

A mesma classe `MatriculaService` é utilizada com as duas implementações:

```java
MatriculaService service =
        new MatriculaService(new AlunoDAOMemoria());
```

e:

```java
MatriculaService outroService =
        new MatriculaService(new AlunoDAOAlternativo());
```

A regra de negócio permanece a mesma.

Somente a implementação responsável pelos dados é substituída.

Isso demonstra a separação entre negócio e persistência e a dependência da abstração.

## Estrutura do projeto

```text
TP2_Aula07_DAO/
│
├── README.md
│
├── src/
│   ├── Aluno.java
│   ├── AlunoDAO.java
│   ├── AlunoDAOMemoria.java
│   ├── AlunoDAOAlternativo.java
│   ├── MatriculaService.java
│   └── Main.java
│
└── uml/
    └── diagrama-final.puml
```

## Como compilar

É necessário utilizar Java JDK 17 ou superior.

No terminal, dentro da pasta do projeto:

```bash
javac -d out src/*.java
```

## Como executar

Depois da compilação:

```bash
java -cp out Main
```

## Resultado esperado

O programa deve:

1. Cadastrar alunos usando `AlunoDAOMemoria`.
2. Listar os alunos.
3. Buscar um aluno.
4. Atualizar um aluno.
5. Remover um aluno.
6. Trocar para `AlunoDAOAlternativo`.
7. Utilizar a mesma `MatriculaService` sem modificar sua regra de negócio.

## Padrões e princípios demonstrados

- DAO
- SRP - Princípio da Responsabilidade Única
- DIP - Princípio da Inversão de Dependência
- Separação entre regra de negócio e persistência
- Dependência de abstração
