public class Main {

    public static void main(String[] args) {

        System.out.println("===== AULA 7 - PADRÃO DAO =====");

        System.out.println();
        System.out.println("===== ETAPA 3 - ALUNODAO EM MEMÓRIA =====");

        AlunoDAO daoMemoria = new AlunoDAOMemoria();
        MatriculaService service = new MatriculaService(daoMemoria);

        service.cadastrarAluno(new Aluno(1, "Ana Silva", "2026001"));
        service.cadastrarAluno(new Aluno(2, "Bruno Costa", "2026002"));
        service.cadastrarAluno(new Aluno(3, "Carla Dias", "2026003"));

        System.out.println("Alunos cadastrados:");
        service.listarAlunos();

        System.out.println();
        System.out.println("Busca pelo ID 2:");
        System.out.println(service.buscarAluno(2));

        System.out.println();
        System.out.println("Atualização do aluno 2:");

        Aluno alunoAtualizado = service.buscarAluno(2);
        alunoAtualizado.setNome("Bruno Costa Atualizado");
        service.atualizarAluno(alunoAtualizado);

        System.out.println(service.buscarAluno(2));

        System.out.println();
        System.out.println("Remoção do aluno 3:");
        service.removerAluno(3);
        service.listarAlunos();

        System.out.println();
        System.out.println("===== ETAPA 5 - TROCA DA IMPLEMENTAÇÃO =====");

        AlunoDAO outroDAO = new AlunoDAOAlternativo();

        // A mesma classe de negócio é utilizada com outra implementação.
        MatriculaService outroService = new MatriculaService(outroDAO);

        outroService.cadastrarAluno(new Aluno(10, "Diego Martins", "2026010"));
        outroService.cadastrarAluno(new Aluno(11, "Mariana Souza", "2026011"));

        System.out.println("Alunos usando AlunoDAOAlternativo:");
        outroService.listarAlunos();

        System.out.println();
        System.out.println("A regra de negócio não foi alterada.");
        System.out.println("Apenas a implementação do DAO foi substituída.");
        System.out.println();
        System.out.println("Todos os testes foram executados com sucesso.");
    }
}
