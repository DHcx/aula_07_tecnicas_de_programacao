public class MatriculaService {

    private final AlunoDAO alunoDAO;

    public MatriculaService(AlunoDAO alunoDAO) {
        this.alunoDAO = alunoDAO;
    }

    public void cadastrarAluno(Aluno aluno) {
        if (aluno == null) {
            throw new IllegalArgumentException("Aluno não pode ser nulo.");
        }

        if (aluno.getNome() == null || aluno.getNome().isBlank()) {
            throw new IllegalArgumentException("Nome do aluno é obrigatório.");
        }

        if (aluno.getMatricula() == null || aluno.getMatricula().isBlank()) {
            throw new IllegalArgumentException("Matrícula é obrigatória.");
        }

        alunoDAO.inserir(aluno);
    }

    public Aluno buscarAluno(int id) {
        return alunoDAO.buscar(id);
    }

    public void atualizarAluno(Aluno aluno) {
        alunoDAO.atualizar(aluno);
    }

    public void removerAluno(int id) {
        alunoDAO.remover(id);
    }

    public void listarAlunos() {
        for (Aluno aluno : alunoDAO.listar()) {
            System.out.println(aluno);
        }
    }
}
