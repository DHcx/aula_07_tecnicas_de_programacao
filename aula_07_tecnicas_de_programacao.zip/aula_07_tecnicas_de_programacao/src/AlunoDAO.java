import java.util.List;

public interface AlunoDAO {

    void inserir(Aluno aluno);

    Aluno buscar(int id);

    List<Aluno> listar();

    void atualizar(Aluno aluno);

    void remover(int id);
}
