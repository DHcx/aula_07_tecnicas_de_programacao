import java.util.ArrayList;
import java.util.List;

public class AlunoDAOAlternativo implements AlunoDAO {

    private final List<Aluno> alunos = new ArrayList<>();

    @Override
    public void inserir(Aluno aluno) {
        if (aluno == null) {
            throw new IllegalArgumentException("Aluno não pode ser nulo.");
        }

        if (buscar(aluno.getId()) != null) {
            throw new IllegalArgumentException("Já existe um aluno com este ID.");
        }

        alunos.add(aluno);
    }

    @Override
    public Aluno buscar(int id) {
        for (Aluno aluno : alunos) {
            if (aluno.getId() == id) {
                return aluno;
            }
        }

        return null;
    }

    @Override
    public List<Aluno> listar() {
        return new ArrayList<>(alunos);
    }

    @Override
    public void atualizar(Aluno aluno) {
        if (aluno == null) {
            throw new IllegalArgumentException("Aluno não pode ser nulo.");
        }

        for (int i = 0; i < alunos.size(); i++) {
            if (alunos.get(i).getId() == aluno.getId()) {
                alunos.set(i, aluno);
                return;
            }
        }

        throw new IllegalArgumentException("Aluno não encontrado.");
    }

    @Override
    public void remover(int id) {
        alunos.removeIf(aluno -> aluno.getId() == id);
    }
}
