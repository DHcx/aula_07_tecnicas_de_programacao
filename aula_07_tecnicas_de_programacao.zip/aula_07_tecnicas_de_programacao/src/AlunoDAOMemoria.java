import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AlunoDAOMemoria implements AlunoDAO {

    private final Map<Integer, Aluno> alunos = new LinkedHashMap<>();

    @Override
    public void inserir(Aluno aluno) {
        if (aluno == null) {
            throw new IllegalArgumentException("Aluno não pode ser nulo.");
        }

        if (alunos.containsKey(aluno.getId())) {
            throw new IllegalArgumentException("Já existe um aluno com este ID.");
        }

        alunos.put(aluno.getId(), aluno);
    }

    @Override
    public Aluno buscar(int id) {
        return alunos.get(id);
    }

    @Override
    public List<Aluno> listar() {
        return new ArrayList<>(alunos.values());
    }

    @Override
    public void atualizar(Aluno aluno) {
        if (aluno == null) {
            throw new IllegalArgumentException("Aluno não pode ser nulo.");
        }

        if (!alunos.containsKey(aluno.getId())) {
            throw new IllegalArgumentException("Aluno não encontrado.");
        }

        alunos.put(aluno.getId(), aluno);
    }

    @Override
    public void remover(int id) {
        alunos.remove(id);
    }
}
